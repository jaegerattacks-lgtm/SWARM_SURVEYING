import SwiftUI

@main
struct ARKitRobotApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
