#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry
from geometry_msgs.msg import PolygonStamped, Point32
from std_msgs.msg import String
import numpy as np
from scipy.spatial import Voronoi
from shapely.geometry import Polygon, Point

class VoronoiPartitionNode(Node):
    def __init__(self):
        super().__init__('voronoi_partition_node')
        self.declare_parameter('robot_id', 1)
        self.robot_id = self.get_parameter('robot_id').value

        # Boundary of newmap.yaml
        tilted_corners = [(0.0, 0.0), (0.0, 33.0), (97.7, 33.0), (97.7, 0.0)]
        self.boundary_polygon = Polygon(tilted_corners)

        self.robot_poses = {1: None, 2: None, 3: None}
        self.locked_polygon = None
        self.mission_started = False

        # --- THE HEARTBEAT (Added this back!) ---
        self.heartbeat_pub = self.create_publisher(String, '/robot_heartbeat', 10)
        self.heartbeat_timer = self.create_timer(1.0, self.publish_heartbeat)

        # Track positions until mission starts
        self.odom_sub_1 = self.create_subscription(Odometry, '/tb1/odom', lambda msg: self.odom_cb(msg, 1), 10)
        self.odom_sub_2 = self.create_subscription(Odometry, '/tb2/odom', lambda msg: self.odom_cb(msg, 2), 10)
        self.odom_sub_3 = self.create_subscription(Odometry, '/tb3/odom', lambda msg: self.odom_cb(msg, 3), 10)
        self.command_sub = self.create_subscription(String, '/swarm_command', self.command_callback, 10)

        # Publish the assigned zone
        self.zone_pub = self.create_publisher(PolygonStamped, f'/tb{self.robot_id}/assigned_zone', 10)
        self.timer = self.create_timer(0.5, self.publish_zone)
        self.get_logger().info(f"Voronoi Node {self.robot_id} started. Waiting for START command to lock fence.")

    def publish_heartbeat(self):
        msg = String()
        msg.data = f'tb{self.robot_id}'
        self.heartbeat_pub.publish(msg)

    def odom_cb(self, msg, r_id):
        if not self.mission_started:
            self.robot_poses[r_id] = (msg.pose.pose.position.x, msg.pose.pose.position.y)

    def command_callback(self, msg):
        if msg.data == 'START' and not self.mission_started:
            self.mission_started = True
            self.get_logger().info('START received! LOCKING VORONOI FENCES FOREVER.')
            self.calculate_and_lock_voronoi()

    def calculate_and_lock_voronoi(self):
        seeds = []
        valid_ids = []
        for r_id in [1, 2, 3]:
            if self.robot_poses[r_id] is not None:
                seeds.append(self.robot_poses[r_id])
                valid_ids.append(r_id)

        if len(seeds) < 2:
            self.locked_polygon = self.boundary_polygon
            return

        seed_array = np.array(seeds)
        minx, miny, maxx, maxy = self.boundary_polygon.bounds
        margin = max(maxx - minx, maxy - miny) * 10

        # Mirror points to close the polygons around the map edges
        mirror_points = []
        for x, y in seeds:
            mirror_points += [
                (x + margin, y), (x - margin, y),
                (x, y + margin), (x, y - margin)
            ]

        all_points = np.vstack([seed_array, mirror_points])
        vor = Voronoi(all_points)

        for i, r_id in enumerate(valid_ids):
            if r_id == self.robot_id:
                region_idx = vor.point_region[i]
                vertices = vor.regions[region_idx]
                poly = Polygon(vor.vertices[vertices])
                self.locked_polygon = poly.intersection(self.boundary_polygon)
                break

    def publish_zone(self):
        if self.locked_polygon is not None:
            msg = PolygonStamped()
            msg.header.stamp = self.get_clock().now().to_msg()
            msg.header.frame_id = 'map'
            for coord in self.locked_polygon.exterior.coords:
                pt = Point32()
                pt.x, pt.y, pt.z = float(coord[0]), float(coord[1]), 0.0
                msg.polygon.points.append(pt)
            self.zone_pub.publish(msg)

def main(args=None):
    rclpy.init(args=args)
    node = VoronoiPartitionNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok(): rclpy.shutdown()

if __name__ == '__main__':
    main()
