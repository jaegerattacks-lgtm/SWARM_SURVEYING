#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from nav_msgs.msg import OccupancyGrid
from geometry_msgs.msg import PoseStamped, PolygonStamped
from std_msgs.msg import String
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy, DurabilityPolicy
from tf2_ros import Buffer, TransformListener
import numpy as np
import math
from shapely.geometry import Point, Polygon

class StigmergyPlanner(Node):
    def __init__(self):
        super().__init__('stigmergy_planner')
        
        self.declare_parameter('robot_id', 1)
        self.robot_id = self.get_parameter('robot_id').value
        
        self.mission_started = False
        self.mission_complete = False
        self.my_polygon = None
        
        self.command_sub = self.create_subscription(String, '/swarm_command', self.command_callback, 10)
        self.zone_sub = self.create_subscription(PolygonStamped, f'/tb{self.robot_id}/assigned_zone', self.zone_callback, 10)

        self.map_received = False
        self.pose_received = False
        self.grid = None  
        self.static_map = None 
        
        # متغيرات حساب الـ 85%
        self.total_zone_cells = 0
        self.painted_cells = 0
        
        self.curr_x, self.curr_y, self.curr_yaw = 0.0, 0.0, 0.0
        self.active_goal_x, self.active_goal_y, self.active_goal_yaw = None, None, None 
        self.last_x, self.last_y, self.last_yaw = 0.0, 0.0, 0.0 
        self.stuck_ticks = 0
        self.pause_planning_until = 0  
        
        self.min_x, self.max_x, self.min_y, self.max_y = 0.0, 0.0, 0.0, 0.0
        
        # --- NETWORK OPTIMIZATION COUNTER ---
        self.publish_counter = 0
        
        map_qos = QoSProfile(reliability=ReliabilityPolicy.RELIABLE, durability=DurabilityPolicy.TRANSIENT_LOCAL, depth=1)
        
        self.map_sub = self.create_subscription(OccupancyGrid, 'map', self.map_callback, map_qos)
        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)
        
        self.goal_pub = self.create_publisher(PoseStamped, 'goal_pose', 10)
        self.pheromone_pub = self.create_publisher(OccupancyGrid, 'pheromone_map', 10)

        self.paint_timer = self.create_timer(0.2, self.update_pose_and_paint)
        self.plan_timer = self.create_timer(0.5, self.planning_loop) 

    def command_callback(self, msg):
        if msg.data == 'START':
            self.mission_started = True

    def zone_callback(self, msg):
        if self.my_polygon is not None: return # نستلمها مرة واحدة ونثبتها
        coords = [(pt.x, pt.y) for pt in msg.polygon.points]
        if len(coords) >= 3:
            self.my_polygon = Polygon(coords)
            self.calculate_zone_area() # نحسب مساحة الزون كام خلية

    def calculate_zone_area(self):
        if not self.map_received or self.my_polygon is None: return
        minx, miny, maxx, maxy = self.my_polygon.bounds
        res = self.info.resolution
        origin_x, origin_y = self.info.origin.position.x, self.info.origin.position.y

        min_gx = max(0, int((minx - origin_x) / res))
        max_gx = min(self.info.width, int((maxx - origin_x) / res) + 1)
        min_gy = max(0, int((miny - origin_y) / res))
        max_gy = min(self.info.height, int((maxy - origin_y) / res) + 1)

        cells = 0
        for gy in range(min_gy, max_gy):
            for gx in range(min_gx, max_gx):
                idx = gy * self.info.width + gx
                if self.static_map[idx] < 90: # خلية فاضية
                    tx = (gx * res) + origin_x
                    ty = (gy * res) + origin_y
                    if self.my_polygon.contains(Point(tx, ty)):
                        cells += 1
        self.total_zone_cells = cells

    def euler_from_quaternion(self, q):
        siny_cosp = 2 * (q.w * q.z + q.x * q.y)
        cosy_cosp = 1 - 2 * (q.y * q.y + q.z * q.z)
        return math.atan2(siny_cosp, cosy_cosp)

    def map_callback(self, msg):
        if self.map_received: return
        current_map = np.array(msg.data, dtype=np.int8)
        self.info = msg.info
        self.static_map = np.copy(current_map) 
        self.grid = np.copy(current_map) 
        
        res = msg.info.resolution
        self.min_x = msg.info.origin.position.x + 0.25
        self.max_x = msg.info.origin.position.x + (msg.info.width * res) - 0.25
        self.min_y = msg.info.origin.position.y + 0.25
        self.max_y = msg.info.origin.position.y + (msg.info.height * res) - 0.25
        self.map_received = True

    def is_cell_safe(self, gx, gy, safe_dist_m=0.3):
        safe_cells = int(safe_dist_m / self.info.resolution)
        for i in range(-safe_cells, safe_cells + 1):
            for j in range(-safe_cells, safe_cells + 1):
                if i*i + j*j > safe_cells*safe_cells: continue
                check_gx, check_gy = gx + i, gy + j
                if 0 <= check_gx < self.info.width and 0 <= check_gy < self.info.height:
                    if self.static_map[check_gy * self.info.width + check_gx] >= 90:
                        return False
        return True

    def get_cluster_score(self, gx, gy, search_radius_m=1.5):
        radius_cells = int(search_radius_m / self.info.resolution)
        grid_2d = self.grid.reshape((self.info.height, self.info.width))
        y_min, y_max = max(0, gy - radius_cells), min(self.info.height, gy + radius_cells + 1)
        x_min, x_max = max(0, gx - radius_cells) , min(self.info.width, gx + radius_cells + 1)
        
        subgrid = grid_2d[y_min:y_max, x_min:x_max]
        empty_cells = np.count_nonzero(subgrid <= 10)
        max_possible_cells = (2 * radius_cells) ** 2
        if max_possible_cells == 0: return 0.0
        return (empty_cells / max_possible_cells) * 100.0

    def update_pose_and_paint(self):
        if not self.mission_started or not self.map_received or self.mission_complete: return
        
        try:
            trans = self.tf_buffer.lookup_transform('map', f'tb{self.robot_id}/base_link', rclpy.time.Time())
            self.curr_x, self.curr_y = trans.transform.translation.x, trans.transform.translation.y
            self.curr_yaw = self.euler_from_quaternion(trans.transform.rotation)
            self.pose_received = True
        except: return 
            
        gx = int((self.curr_x - self.info.origin.position.x) / self.info.resolution)
        gy = int((self.curr_y - self.info.origin.position.y) / self.info.resolution)
        
        brush_radius_m = 1.0 
        radius_cells = int(brush_radius_m / self.info.resolution)
        radius_sq = radius_cells * radius_cells

        queue = [(gx, gy)]
        visited = {(gx, gy)}

        if 0 <= gx < self.info.width and 0 <= gy < self.info.height:
            start_idx = gy * self.info.width + gx
            if self.static_map[start_idx] < 90: 
                while queue:
                    cx, cy = queue.pop(0)
                    idx = cy * self.info.width + cx
                    
                    if self.grid[idx] <= 10: 
                        self.grid[idx] = 60
                        self.painted_cells += 1 # نزود العداد بتاع المسح
                        
                    for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1), (-1, -1), (-1, 1), (1, -1), (1, 1)]:
                        nx, ny = cx + dx, cy + dy
                        if (nx, ny) not in visited:
                            if 0 <= nx < self.info.width and 0 <= ny < self.info.height:
                                if (nx - gx)**2 + (ny - gy)**2 <= radius_sq:
                                    n_idx = ny * self.info.width + nx
                                    if self.static_map[n_idx] < 90: 
                                        visited.add((nx, ny))
                                        queue.append((nx, ny))
                        
        # --- NETWORK OPTIMIZATION: ONLY PUBLISH TO RVIZ EVERY 1 SECOND ---
        self.publish_counter += 1
        if self.publish_counter % 5 == 0:
            viz_msg = OccupancyGrid()
            viz_msg.header.frame_id = 'map'
            viz_msg.info = self.info
            viz_msg.data = self.grid.tolist()
            self.pheromone_pub.publish(viz_msg)
            self.publish_counter = 0

        # ----- فحص نسبة المسح والتقرير النهائي -----
        if self.total_zone_cells > 0:
            coverage = (self.painted_cells / self.total_zone_cells) * 100.0
            if coverage >= 85.0 and not self.mission_complete:
                self.mission_complete = True
                self.get_logger().info(f"\n======================================================\nFINAL REPORT: Robot {self.robot_id} scanned {coverage:.1f}% of its assigned area.\nMISSION COMPLETE!\n======================================================")
                self.active_goal_x = None

    def planning_loop(self):
        if not self.mission_started or not self.map_received or not self.pose_received or self.my_polygon is None or self.mission_complete: 
            return

        current_time_ns = self.get_clock().now().nanoseconds
        if current_time_ns < self.pause_planning_until:
            return  

        if self.active_goal_x is not None:
            dist_to_goal = math.hypot(self.curr_x - self.active_goal_x, self.curr_y - self.active_goal_y)
            dist_moved = math.hypot(self.curr_x - self.last_x, self.curr_y - self.last_y)
            
            self.last_x, self.last_y = self.curr_x, self.curr_y
            
            if dist_to_goal > 1.0:
                if dist_moved < 0.05: 
                    self.stuck_ticks += 1
                else:
                    self.stuck_ticks = 0 
                    
                if self.stuck_ticks > 15: 
                    self.active_goal_x = None
                    self.stuck_ticks = 0
                    return 
                return 
            else:
                self.stuck_ticks = 0

        best_goal, best_score = None, 0.0 
        search_range = 4.0 
        step = 0.8 
        
        for dx in np.arange(-search_range, search_range + 0.1, step):
            for dy in np.arange(-search_range, search_range + 0.1, step):
                if abs(dx) < 0.5 and abs(dy) < 0.5: continue
                tx, ty = self.curr_x + dx, self.curr_y + dy
                
                if not self.my_polygon.contains(Point(tx, ty)): continue

                if self.min_x < tx < self.max_x and self.min_y < ty < self.max_y:
                    gx = int((tx - self.info.origin.position.x) / self.info.resolution)
                    gy = int((ty - self.info.origin.position.y) / self.info.resolution)
                    
                    if 0 <= gx < self.info.width and 0 <= gy < self.info.height:
                        if self.is_cell_safe(gx, gy):
                            density_percent = self.get_cluster_score(gx, gy)
                            if density_percent >= 2.0:
                                target_angle = math.atan2(dy, dx)
                                angle_diff = math.atan2(math.sin(target_angle - self.curr_yaw), math.cos(target_angle - self.curr_yaw))
                                
                                idx = gy * self.info.width + gx
                                is_visited = (self.grid[idx] == 60)
                                # عقوبة قاسية جداً عشان ميمشيش فوق لونه تاني!
                                pheromone_penalty = 2000.0 if is_visited else 0.0
                                
                                total_score = (density_percent * 2.0) - (math.hypot(dx, dy) * 5.0) + (math.cos(angle_diff) * 100.0) - pheromone_penalty
                                
                                if total_score > best_score:
                                    best_score = total_score
                                    best_goal = (tx, ty, target_angle)
        
        # لو مفيش مسار واضح جنبه، يدور في الخريطة كلها على نقطة مسحهاش
        if not best_goal:
            unvisited_indices = np.where(self.grid <= 10)[0]
            if len(unvisited_indices) > 0:
                gy_unvisited, gx_unvisited = np.unravel_index(unvisited_indices, (self.info.height, self.info.width))
                tx_unvisited = (gx_unvisited * self.info.resolution) + self.info.origin.position.x
                ty_unvisited = (gy_unvisited * self.info.resolution) + self.info.origin.position.y
                
                valid_mask = (tx_unvisited >= self.min_x) & (tx_unvisited <= self.max_x) & (ty_unvisited >= self.min_y) & (ty_unvisited <= self.max_y)
                tx_valid = tx_unvisited[valid_mask]
                ty_valid = ty_unvisited[valid_mask]
                
                if len(tx_valid) > 0:
                    sample_indices = np.arange(0, len(tx_valid), max(1, len(tx_valid) // 30))
                    best_escape_score = -float('inf')
                    
                    for idx in sample_indices:
                        nearest_tx, nearest_ty = tx_valid[idx], ty_valid[idx]
                        if not self.my_polygon.contains(Point(nearest_tx, nearest_ty)): continue

                        gx = int((nearest_tx - self.info.origin.position.x) / self.info.resolution)
                        gy = int((nearest_ty - self.info.origin.position.y) / self.info.resolution)
                        
                        if self.is_cell_safe(gx, gy):
                            density_percent = self.get_cluster_score(gx, gy)
                            if density_percent >= 5.0:
                                dist_to_p = math.hypot(nearest_tx - self.curr_x, nearest_ty - self.curr_y)
                                score = (density_percent * 2.0) - dist_to_p 
                                if score > best_escape_score:
                                    best_escape_score = score
                                    angle_to_target = math.atan2(nearest_ty - self.curr_y, nearest_tx - self.curr_x)
                                    best_goal = (nearest_tx, nearest_ty, angle_to_target)

        if best_goal:
            self.active_goal_x, self.active_goal_y, self.active_goal_yaw = best_goal
            self.send_nav2_goal(*best_goal)
            self.pause_planning_until = current_time_ns + int(1.0 * 1e9) 

    def send_nav2_goal(self, x, y, yaw):
        goal = PoseStamped()
        goal.header.frame_id = "map"
        goal.header.stamp = self.get_clock().now().to_msg()
        goal.pose.position.x, goal.pose.position.y = float(x), float(y)
        goal.pose.orientation.z, goal.pose.orientation.w = math.sin(yaw/2), math.cos(yaw/2)
        self.goal_pub.publish(goal)

def main(args=None):
    rclpy.init(args=args)
    node = StigmergyPlanner()
    try: rclpy.spin(node)
    except KeyboardInterrupt: pass
    finally:
        node.destroy_node()
        if rclpy.ok(): rclpy.shutdown()

if __name__ == '__main__':
    main()
