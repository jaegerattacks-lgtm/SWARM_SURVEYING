import os
from glob import glob
from setuptools import find_packages, setup

package_name = 'swarm_bringup'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        # These lines tell ROS 2 to compile your launch, worlds, and maps folders
        (os.path.join('share', package_name, 'launch'), glob(os.path.join('launch', '*launch.[pxy][yma]*'))),
        (os.path.join('share', package_name, 'worlds'), glob(os.path.join('worlds', '*.world'))),
        (os.path.join('share', package_name, 'maps'), glob(os.path.join('maps', '*'))),
        
        # --- NEW: Tell ROS 2 to compile the params folder ---
        (os.path.join('share', package_name, 'params'), glob(os.path.join('params', '*.yaml'))),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Taha',
    maintainer_email='your_email@example.com',
    description='Bringup package for the swarm survey project',
    license='Apache-2.0',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            # --- NEW: Tell ROS 2 exactly where your Stigmergy node is ---
            'stigmergy_planner = swarm_bringup.stigmergy_planner:main',
        ],
    },
)
