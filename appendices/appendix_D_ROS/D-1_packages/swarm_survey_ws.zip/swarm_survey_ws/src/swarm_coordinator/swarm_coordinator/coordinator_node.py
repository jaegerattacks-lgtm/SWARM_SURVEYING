import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient
from std_msgs.msg import Int32, String
from nav2_msgs.action import NavigateToPose
import numpy as np
import math
from shapely.geometry import Polygon

class SwarmCoordinatorNode(Node):
    def __init__(self):
        super().__init__('swarm_coordinator_node')

        self.declare_parameter('expected_robots', 3)
        self.expected = self.get_parameter('expected_robots').value
        self.active_robots = set()

        self.tilted_corners = [
            (0.0, 0.0),       
            (0.0, 33.0),      
            (97.7, 33.0),     
            (97.7, 0.0)       
        ]
        self.boundary_polygon = Polygon(self.tilted_corners)

        self.heartbeat_sub = self.create_subscription(String, '/robot_heartbeat', self.on_heartbeat, 10)
        self.count_pub = self.create_publisher(Int32, '/active_robot_count', 10)
        
        # The Megaphone to wake up the robots
        self.command_pub = self.create_publisher(String, '/swarm_command', 10)

        # Nav2 Action Tracking
        self.nav_clients = {}
        self.robots_reached_goal = 0
        self.total_robots_dispatched = 0

        self.timer = self.create_timer(10.0, self.finalize_count)
        self.finalized = False
        self.get_logger().info('Coordinator: waiting 10s for robots to wake up...')

    def on_heartbeat(self, msg):
        if not self.finalized:
            self.active_robots.add(msg.data)
            self.get_logger().info(f'Heard from {msg.data} — total so far: {len(self.active_robots)}')

    def finalize_count(self):
        if not self.finalized:
            self.finalized = True
            n_active = len(self.active_robots)
            
            count_msg = Int32()
            count_msg.data = n_active
            self.count_pub.publish(count_msg)
            
            self.get_logger().info(f'LOCKED: {n_active} robots active.')
            self.timer.cancel()

            if n_active > 0:
                self.get_logger().info('Calculating optimal deployment waypoints...')
                self.calculate_longest_diagonal_nodes(n_active)
            else:
                self.get_logger().error('No robots found. Mission aborted.')

    def calculate_longest_diagonal_nodes(self, n_robots):
        corners = list(self.boundary_polygon.exterior.coords)[:-1]
        
        max_dist = 0
        point_A = None
        point_B = None

        for i in range(len(corners)):
            for j in range(i + 1, len(corners)):
                dist = math.dist(corners[i], corners[j])
                if dist > max_dist:
                    max_dist = dist
                    point_A = corners[i]
                    point_B = corners[j]

        A = np.array(point_A)
        B = np.array(point_B)
        
        sorted_robots = sorted(list(self.active_robots))
        self.total_robots_dispatched = len(sorted_robots)

        for i, robot_id in enumerate(sorted_robots):
            fraction = (i + 1) / (n_robots + 1)
            target_pt = A + fraction * (B - A)
            
            self.get_logger().info(f"==> Sending {robot_id} to X: {target_pt[0]:.2f}, Y: {target_pt[1]:.2f}")
            self.send_nav_goal(robot_id, target_pt[0], target_pt[1])

    # --- Nav2 Action Client Logic ---
    def send_nav_goal(self, robot_id, x, y):
        action_name = f'/{robot_id}/navigate_to_pose'
        client = ActionClient(self, NavigateToPose, action_name)
        self.nav_clients[robot_id] = client

        goal_msg = NavigateToPose.Goal()
        goal_msg.pose.header.frame_id = 'map'
        goal_msg.pose.pose.position.x = float(x)
        goal_msg.pose.pose.position.y = float(y)
        goal_msg.pose.pose.orientation.w = 1.0 # Face forward

        client.wait_for_server()
        
        send_goal_future = client.send_goal_async(goal_msg)
        send_goal_future.add_done_callback(lambda future, rid=robot_id: self.goal_response_callback(future, rid))

    def goal_response_callback(self, future, robot_id):
        goal_handle = future.result()
        if not goal_handle.accepted:
            self.get_logger().error(f'Goal rejected for {robot_id}!')
            return
            
        self.get_logger().info(f'{robot_id} is driving to destination...')
        get_result_future = goal_handle.get_result_async()
        get_result_future.add_done_callback(lambda future, rid=robot_id: self.get_result_callback(future, rid))

    def get_result_callback(self, future, robot_id):
        self.get_logger().info(f'{robot_id} has arrived at its waypoint!')
        self.robots_reached_goal += 1
        
        # Check if all robots have arrived
        if self.robots_reached_goal == self.total_robots_dispatched:
            self.get_logger().info('ALL ROBOTS DEPLOYED. Triggering Voronoi Partitioning!')
            
            msg = String()
            msg.data = 'START'
            self.command_pub.publish(msg)

def main(args=None):
    rclpy.init(args=args)
    node = SwarmCoordinatorNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()

if __name__ == '__main__':
    main()
