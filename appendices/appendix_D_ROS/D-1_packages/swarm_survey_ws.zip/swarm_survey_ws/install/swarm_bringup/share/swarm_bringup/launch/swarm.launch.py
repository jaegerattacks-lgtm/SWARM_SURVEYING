import os
import re
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, GroupAction
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node, PushRosNamespace


def generate_launch_description():
    ld = LaunchDescription()

    bringup_dir = get_package_share_directory('swarm_bringup')

    # --- 1. START GAZEBO ---
    world_path = os.path.join(bringup_dir, 'worlds', 'newworld.world')
    gazebo_pkg = get_package_share_directory('gazebo_ros')
    ld.add_action(IncludeLaunchDescription(
        PythonLaunchDescriptionSource(os.path.join(gazebo_pkg, 'launch', 'gazebo.launch.py')),
        launch_arguments={'world': world_path}.items()
    ))

    # --- 2. GLOBAL SYSTEM FILES ---
    tb3_model = os.environ.get('TURTLEBOT3_MODEL', 'waffle')
    tb3_model_path = os.path.join(
        get_package_share_directory('turtlebot3_gazebo'), 'models', f'turtlebot3_{tb3_model}', 'model.sdf'
    )

    urdf_file_name = f'turtlebot3_{tb3_model}.urdf'
    urdf_path = os.path.join(
        get_package_share_directory('turtlebot3_description'), 'urdf', urdf_file_name
    )
    with open(urdf_path, 'r') as infp:
        robot_desc = infp.read()

    # Strip the literal ${namespace} placeholder so RSP publishes clean
    # base_link etc., which frame_prefix then turns into tbX/base_link.
    robot_desc = robot_desc.replace('${namespace}', '')

    # Read the stock SDF once; we namespace its TF frames per robot below.
    with open(tb3_model_path, 'r') as infp:
        sdf_template = infp.read()

    map_yaml_file = os.path.join(bringup_dir, 'maps', 'newmap.yaml')
    nav2_params_file = os.path.join(bringup_dir, 'params', 'nav2_multirobot_params.yaml')
    nav2_bringup_dir = get_package_share_directory('nav2_bringup')

    tf_remaps = [('/tf', 'tf'), ('/tf_static', 'tf_static')]

    # --- 3. START THE COORDINATOR (The Boss) ---
    coordinator_node = Node(
        package='swarm_coordinator',
        executable='swarm_coordinator_node',
        output='screen'
    )
    ld.add_action(coordinator_node)

    # --- 4. ROBOT CONFIGURATIONS ---
    #  >>> set these to your actual desired spawn coordinates <<<
    robots = [
        {'name': 'tb1', 'id': 1, 'x': '45.0', 'y': '15.0'},
        {'name': 'tb2', 'id': 2, 'x': '48.85', 'y': '16.5'},
        {'name': 'tb3', 'id': 3, 'x': '50.0', 'y': '20.0'},
    ]

    # --- 5. THE SWARM LOOP ---
    for robot in robots:
        name = robot['name']

        # A. Per-robot SDF with PREFIXED tf frames on the namespaced /tbX/tf.
        robot_sdf = sdf_template
        robot_sdf = robot_sdf.replace(
            '<odometry_frame>odom</odometry_frame>',
            f'<odometry_frame>{name}/odom</odometry_frame>')
        robot_sdf = robot_sdf.replace(
            '<robot_base_frame>base_footprint</robot_base_frame>',
            f'<robot_base_frame>{name}/base_footprint</robot_base_frame>')
        robot_sdf = robot_sdf.replace(
            '<frame_name>base_scan</frame_name>',
            f'<frame_name>{name}/base_scan</frame_name>')
        robot_sdf = re.sub(
            r'(<plugin name="turtlebot3_diff_drive"[^>]*>\s*<ros>)',
            r'\1\n          <remapping>/tf:=tf</remapping>'
            r'\n          <remapping>/tf_static:=tf_static</remapping>',
            robot_sdf)

        tmp_sdf_path = os.path.join('/tmp', f'{name}_model.sdf')
        with open(tmp_sdf_path, 'w') as f:
            f.write(robot_sdf)

        # B. Spawn the robot in Gazebo
        spawn_node = Node(
            package='gazebo_ros',
            executable='spawn_entity.py',
            arguments=[
                '-entity', name,
                '-file', tmp_sdf_path,
                '-x', robot['x'],
                '-y', robot['y'],
                '-z', '0.01',
                '-robot_namespace', name
            ],
            output='screen'
        )
        ld.add_action(spawn_node)

        # C. Robot State Publisher (prefixed skeleton + /tf remap -> /tbX/tf)
        rsp_node = Node(
            package='robot_state_publisher',
            executable='robot_state_publisher',
            namespace=name,
            output='screen',
            parameters=[{
                'use_sim_time': True,
                'robot_description': robot_desc,
                'frame_prefix': name + '/'
            }],
            remappings=tf_remaps
        )
        ld.add_action(rsp_node)

        # D. Static map -> tbX/odom transform
        static_tf_node = Node(
            package='tf2_ros',
            executable='static_transform_publisher',
            namespace=name,
            # FIX: Set all translations to 0.0 to prevent the Double-Offset bug!
            arguments=[
                '--x', '0.0', '--y', '0.0', '--z', '0.0',
                '--yaw', '0.0', '--pitch', '0.0', '--roll', '0.0',
                '--frame-id', 'map', '--child-frame-id', name + '/odom'
            ],
            remappings=tf_remaps,
            output='screen'
        )
        ld.add_action(static_tf_node)
        # E. Per-robot map server publishing /tbX/map
        map_server_node = Node(
            package='nav2_map_server',
            executable='map_server',
            namespace=name,
            name='map_server',
            output='screen',
            parameters=[{'use_sim_time': True, 'yaml_filename': map_yaml_file}],
            remappings=tf_remaps
        )
        ld.add_action(map_server_node)

        map_lifecycle_node = Node(
            package='nav2_lifecycle_manager',
            executable='lifecycle_manager',
            namespace=name,
            name='lifecycle_manager_map',
            output='screen',
            parameters=[{
                'use_sim_time': True,
                'autostart': True,
                'node_names': ['map_server']
            }]
        )
        ld.add_action(map_lifecycle_node)

        # F. Per-robot Nav2 params: substitute the __NS__ token for this robot's
        #    namespace so costmaps/behaviors reference tbX/odom and tbX/base_link.
        #    (Templating instead of RewrittenYaml, because global_frame appears in
        #    both local_costmap [odom] and global_costmap [map] and a key-based
        #    rewrite would clobber the global_costmap's map frame.)
        with open(nav2_params_file, 'r') as f:
            params_text = f.read()
        params_text = params_text.replace('__NS__', name)
        configured_params = os.path.join('/tmp', f'{name}_nav_params.yaml')
        with open(configured_params, 'w') as f:
            f.write(params_text)

        # G. Nav2 NAVIGATION stack, wrapped in PushRosNamespace.
        nav2_group = GroupAction([
            PushRosNamespace(name),
            IncludeLaunchDescription(
                PythonLaunchDescriptionSource(
                    os.path.join(nav2_bringup_dir, 'launch', 'navigation_launch.py')),
                launch_arguments={
                    'namespace': name,
                    'use_sim_time': 'True',
                    'params_file': configured_params,
                    'autostart': 'True',
                    'use_composition': 'False',
                }.items()
            )
        ])
        ld.add_action(nav2_group)

        # H. Custom brains (/tf remap so TransformListener reads /tbX/tf)
        voronoi_node = Node(
            package='voronoi_partition',
            executable='voronoi_partition_node',
            namespace=name,
            parameters=[{'robot_id': robot['id']}],
            remappings=tf_remaps,
            output='screen'
        )
        ld.add_action(voronoi_node)

        stigmergy_node = Node(
            package='swarm_bringup',
            executable='stigmergy_planner',
            namespace=name,
            parameters=[{'robot_id': robot['id']}],
            remappings=tf_remaps,
            output='screen'
        )
        ld.add_action(stigmergy_node)

    return ld
