import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node, SetRemap, SetParameter 

def generate_launch_description():
    MY_PKG = 'tactical_4wd_core'
    pkg_dir = get_package_share_directory(MY_PKG)
    nav2_bringup_dir = get_package_share_directory('nav2_bringup')
    
    params_path = os.path.join(pkg_dir, 'config', 'nav2_params.yaml')
    map_yaml_path = os.path.join(pkg_dir, 'maps', 'trap_map.yaml')
    rviz_config_path = os.path.join(pkg_dir, 'rviz', 'stigmergy_view.rviz')

    return LaunchDescription([
        # --- FORCES SIM TIME GLOBALLY ---
        SetParameter(name='use_sim_time', value=True),
        
        SetRemap(src='/cmd_vel', dst='/diff_drive_controller/cmd_vel_unstamped'),
        SetRemap(src='/odom', dst='/diff_drive_controller/odom'),

        # 1. Map Server
        Node(
            package='nav2_map_server',
            executable='map_server',
            name='map_server',
            output='screen',
            parameters=[{'yaml_filename': map_yaml_path}]
        ),

        # 2. Static TF Publisher (البديل المباشر لـ AMCL)
        Node(
            package='tf2_ros',
            executable='static_transform_publisher',
            name='map_to_odom',
            output='screen',
            # الإحداثيات: X, Y, Z, Yaw, Pitch, Roll, Parent_frame, Child_frame
            arguments=['0', '0', '0', '0', '0', '0', 'map', 'odom']
        ),

        # 3. Lifecycle Manager (تم إزالة amcl من قائمة الإدارة)
        Node(
            package='nav2_lifecycle_manager',
            executable='lifecycle_manager',
            name='lifecycle_manager_localization',
            output='screen',
            parameters=[{'autostart': True, 'node_names': ['map_server']}]
        ),

        # 4. Nav2 Brain
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(os.path.join(nav2_bringup_dir, 'launch', 'navigation_launch.py')),
            launch_arguments={
                'params_file': params_path, 
                'autostart': 'true',
                'use_sim_time': 'true'   # <--- THE CRITICAL SIM TIME FIX
            }.items()
        ),

        # 5. Your Algorithm
        Node(
            package=MY_PKG,
            executable='stigmergy_planner.py',
            name='stigmergy_planner',
            output='screen'
        ),

        # 6. RViz
        Node(
            package='rviz2',
            executable='rviz2',
            name='rviz2',
            arguments=['-d', rviz_config_path]
        ),
        
        # 7. Perfect TF Broadcaster
        Node(
            package=MY_PKG,
            executable='perfect_tf_broadcaster.py',
            name='perfect_tf_broadcaster',
            output='screen'
        ),
        
        
        
    ])
