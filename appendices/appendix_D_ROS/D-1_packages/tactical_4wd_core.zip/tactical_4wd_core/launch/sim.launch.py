import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, ExecuteProcess, RegisterEventHandler, TimerAction
from launch.event_handlers import OnProcessExit
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node, SetParameter  # <--- Imported SetParameter
import xacro

def generate_launch_description():
    pkg_name = 'tactical_4wd_core'
    pkg_dir = get_package_share_directory(pkg_name)
    gazebo_ros_dir = get_package_share_directory('gazebo_ros')

    # --- 1. FILE PATHS ---
    urdf_path = os.path.join(pkg_dir, 'urdf', 'robot_fixed.urdf.xacro')
    # Pointing to your small environment file
    world_path = os.path.join(pkg_dir, 'worlds', 'trap.world')
    controller_config = os.path.join(pkg_dir, 'config', 'my_controllers.yaml')

    # --- 2. PROCESS XACRO ---
    doc = xacro.process_file(urdf_path, mappings={'config_file': controller_config})
    robot_description = {'robot_description': doc.toxml()}

    # --- 3. CORE NODES ---
    node_robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        output='screen',
        parameters=[robot_description, {'use_sim_time': True}]
    )

    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(gazebo_ros_dir, 'launch', 'gazebo.launch.py')
        ),
        # --- BAKE IN THE USE_SIM_TIME ARGUMENT DIRECTLY ---
        launch_arguments={
            'world': world_path,
            'use_sim_time': 'true'
        }.items()
    )

    spawn_entity = Node(
        package='gazebo_ros',
        executable='spawn_entity.py',
        arguments=['-topic', 'robot_description', 
                   '-entity', 'tactical_4wd', 
                   # --- UPDATED SAFE SPAWN COORDINATES ---
                   '-x', '0.0',    
                   '-y', '0.0',   
                   '-z', '0.3'],   # Kept Z slightly elevated for a safe drop
        output='screen'
    )

    # --- 4. CONTROLLERS ---
    load_joint_state_broadcaster = ExecuteProcess(
        cmd=['ros2', 'control', 'load_controller', '--set-state', 'active', 'joint_state_broadcaster'],
        output='screen'
    )

    load_diff_drive_controller = ExecuteProcess(
        cmd=['ros2', 'control', 'load_controller', '--set-state', 'active', 'diff_drive_controller'],
        output='screen'
    )

    # --- 5. SEQUENCING ---
    # We give the small world 5 seconds to load its light and ground
    delayed_spawn = TimerAction(period=5.0, actions=[spawn_entity])

    delay_broadcaster_after_spawn = RegisterEventHandler(
        event_handler=OnProcessExit(
            target_action=spawn_entity,
            on_exit=[load_joint_state_broadcaster],
        )
    )

    delay_diff_drive_after_broadcaster = RegisterEventHandler(
        event_handler=OnProcessExit(
            target_action=load_joint_state_broadcaster,
            on_exit=[load_diff_drive_controller],
        )
    )

    return LaunchDescription([
        # --- GLOBAL OVERRIDE: FORCE SIM TIME ON EVERYTHING IN THIS LAUNCH FILE ---
        SetParameter(name='use_sim_time', value=True),
        node_robot_state_publisher,
        gazebo,
        delayed_spawn,
        delay_broadcaster_after_spawn,
        delay_diff_drive_after_broadcaster
    ])
