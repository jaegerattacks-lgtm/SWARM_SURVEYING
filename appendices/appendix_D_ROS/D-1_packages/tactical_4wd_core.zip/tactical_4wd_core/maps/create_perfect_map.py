#!/usr/bin/env python3
import cv2
import numpy as np
import yaml

def generate_perfect_map():
    resolution = 0.05  # 5cm per pixel
    world_size_m = 30.0
    img_size = int(world_size_m / resolution) # 600x600 pixels
    
    # Create white background (254 = Free)
    map_img = np.full((img_size, img_size), 254, dtype=np.uint8)
    
    def to_px(val):
        # Center is 0,0. Offset by world_size/2 and scale by resolution
        return int((val + (world_size_m / 2)) / resolution)

    # Convert Gazebo (x, y) to Image (x, y)
    def world_to_pixel(x, y):
        px = to_px(x)
        # Invert Y because image coordinates start from top-left
        py = img_size - to_px(y)
        return px, py

    # --- DEFINE OBSTACLES FROM WORLD FILE ---
    # Buildings: (x, y, width, length)
    buildings = [
        (5.0, 5.0, 4.0, 4.0),
        (-8.0, -4.0, 3.0, 6.0),
        (0.0, -10.0, 5.0, 5.0)
    ]
    
    # Trees: (x, y, radius)
    trees = [
        (-5.0, 8.0, 0.5),
        (10.0, -5.0, 0.5),
        (8.0, 12.0, 0.5),
        (-12.0, 10.0, 0.5),
        (-2.0, -2.0, 0.5)
    ]

    # Draw Buildings
    for x, y, w, l in buildings:
        p1 = world_to_pixel(x - w/2, y + l/2)
        p2 = world_to_pixel(x + w/2, y - l/2)
        cv2.rectangle(map_img, p1, p2, 0, -1) # 0 = Occupied

    # Draw Trees
    for x, y, r in trees:
        center = world_to_pixel(x, y)
        cv2.circle(map_img, center, int(r/resolution), 0, -1)

    # Draw Perimeter Wall (8 pixels thick)
    cv2.rectangle(map_img, (0, 0), (img_size-1, img_size-1), 0, 8)

    # Save PGM and YAML
    cv2.imwrite("geometric_map.pgm", map_img)
    
    yaml_data = {
        'image': 'geometric_map.pgm',
        'mode': 'trinary',
        'resolution': resolution,
        'origin': [-15.0, -15.0, 0.0],
        'negate': 0,
        'occupied_thresh': 0.65,
        'free_thresh': 0.25
    }
    
    with open("geometric_map.yaml", 'w') as f:
        yaml.dump(yaml_data, f, default_flow_style=False, sort_keys=False)

    print(f"Map generated! Size: {img_size}x{img_size}, Resolution: {resolution}")

if __name__ == "__main__":
    generate_perfect_map()
