import numpy as np
from PIL import Image

# --- Configuration ---
RESOLUTION = 0.05
WIDTH_M = 14.0  # Padded map width
HEIGHT_M = 19.0 # Padded map height

W_px = int(WIDTH_M / RESOLUTION)
H_px = int(HEIGHT_M / RESOLUTION)

# Initialize map as all BLACK (0 - Obstacle)
# This guarantees the padding outside the walls is a solid, lethal trap
map_data = np.zeros((H_px, W_px), dtype=np.uint8)

# ROS map origin (Bottom-Left corner of the bottom-left pixel)
origin_x = -WIDTH_M / 2.0
origin_y = -HEIGHT_M / 2.0

# --- 1. Carve out the Exact Free Space (White) ---
# True inner boundaries of the Gazebo walls based on a 0.2m thickness
min_x_free = -4.9
max_x_free = 4.9
min_y_free = -7.4
max_y_free = 7.4

# Convert true world boundaries to exact pixel indices
px_start = int(round((min_x_free - origin_x) / RESOLUTION))
px_end = int(round((max_x_free - origin_x) / RESOLUTION))

# In images, row 0 is the TOP (highest Y). We calculate rows from the top down.
top_y = origin_y + HEIGHT_M
row_start = int(round((top_y - max_y_free) / RESOLUTION))
row_end = int(round((top_y - min_y_free) / RESOLUTION))

# Carve the free space with White (254)
map_data[row_start:row_end, px_start:px_end] = 254

# --- Generate exact coordinate grids for the center of every pixel ---
x_coords = np.linspace(origin_x + RESOLUTION/2, origin_x + WIDTH_M - RESOLUTION/2, W_px)
y_coords = np.linspace(origin_y + HEIGHT_M - RESOLUTION/2, origin_y + RESOLUTION/2, H_px)
xx, yy = np.meshgrid(x_coords, y_coords)

# --- 2. Draw Cylinders Vectorized ---
cylinders = [
    (2.0, 4.0, 0.4),
    (-3.0, 5.0, 0.4),
    (3.0, -2.0, 0.4),
    (-2.0, -3.0, 0.4),
    (1.5, -6.0, 0.4),
    (-3.5, -5.0, 0.4)
]

# Apply exact geometric radius formulas
for cx, cy, r in cylinders:
    dist_sq = (xx - cx)**2 + (yy - cy)**2
    # If the pixel center falls inside the cylinder radius, paint it Black (0)
    map_data[dist_sq <= r**2] = 0

# --- 3. Draw Rectangular Traps (NEW) ---
# Format: (min_x, max_x, min_y, max_y)
boxes = [
    # The Recovery Trap (Red U-Shape)
    (-0.4, 0.4, 2.9, 3.1),   # trap_wall_back
    (0.3, 0.5, 1.0, 3.0),    # trap_wall_right
    (-0.5, -0.3, 1.0, 3.0),  # trap_wall_left
    
    # The Narrow Corridor (Blue)
    (-3.6, -3.4, -2.0, 2.0), # corr_wall_left
    (-2.6, -2.4, -2.0, 2.0)  # corr_wall_right
]

for min_x, max_x, min_y, max_y in boxes:
    # Find all pixels that fall within the boundary of each box
    mask = (xx >= min_x) & (xx <= max_x) & (yy >= min_y) & (yy <= max_y)
    # Paint them Black (0)
    map_data[mask] = 0

# --- Save Image ---
img = Image.fromarray(map_data)
img.save("trap_map.pgm")
print("Saved trap_map.pgm")

# --- Generate YAML Config ---
yaml_content = f"""image: trap_map.pgm
resolution: {RESOLUTION}
origin: [{origin_x:.2f}, {origin_y:.2f}, 0.0]
negate: 0
occupied_thresh: 0.65
free_thresh: 0.25
"""

with open("trap_map.yaml", "w") as f:
    f.write(yaml_content)
print("Saved trap_map.yaml")
