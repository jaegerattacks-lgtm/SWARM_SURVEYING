the launch file uses our model xacro file 

to launch this project  you need to launch two files:
1-  ros2 launch tactical_4wd_core sim.launch.py
2-  ros2 launch tactical_4wd_core try_tf.launch.py

you should launch sim.launch.py firstly to laungh the hardare configration 
then the stigmergy algorithm  in the my_robot_model



