import xml.etree.ElementTree as ET
from PIL import Image, ImageDraw
import math

# --- CONFIGURATION ---
SDF_FILE = 'college20.world'  # Change this to your actual SDF file name
MAP_SIZE_M = 60.0             # Your compound is 60x60 meters
RESOLUTION = 0.05             # 0.05 meters per pixel
IMG_SIZE = int(MAP_SIZE_M / RESOLUTION) # 1200 x 1200 pixels
ORIGIN_OFFSET = MAP_SIZE_M / 2          # 30 meters (center of the image)

def gazebo_to_pixel(x, y):
    """Converts Gazebo coordinates (X, Y) to Image Pixels (U, V)"""
    u = int((x + ORIGIN_OFFSET) / RESOLUTION)
    # Image Y axis goes down, Gazebo Y axis goes up, so we invert Y
    v = int((ORIGIN_OFFSET - y) / RESOLUTION)
    return u, v

def draw_item(draw, name, x, y, yaw):
    """Draws an approximate shape based on the model name"""
    px, py = gazebo_to_pixel(x, y)
    
    # 1. Trees (Draw as circles, approx 1.5m radius)
    if 'tree' in name.lower():
        r = int(1.5 / RESOLUTION)
        draw.ellipse([px-r, py-r, px+r, py+r], fill='black')
        print(f"Drew Tree at X:{x}, Y:{y}")

    # 2. People (Draw as small dots, approx 0.3m radius)
    elif 'person' in name.lower():
        r = int(0.3 / RESOLUTION)
        draw.ellipse([px-r, py-r, px+r, py+r], fill='black')
        
    # 3. Buildings / Benches / Everything else (Draw as boxes)
    else:
        # We don't know exact sizes, so we estimate based on name
        if 'house' in name.lower() or 'masjid' in name.lower() or 'building' in name.lower() or 'workshop' in name.lower():
            w, h = 8.0, 8.0 # Estimate 8x8m for buildings
        elif 'bench' in name.lower() or 'table' in name.lower():
            w, h = 1.5, 0.8 # Estimate 1.5x0.8m for furniture
        else:
            w, h = 2.0, 2.0 # Default fallback
            
        w_px, h_px = int(w / RESOLUTION), int(h / RESOLUTION)
        
        # Calculate bounding box (ignoring rotation for simplicity in this base script)
        draw.rectangle([px - w_px/2, py - h_px/2, px + w_px/2, py + h_px/2], fill='black')
        print(f"Drew {name} at X:{x}, Y:{y}")

def main():
    # Create a blank white image
    img = Image.new('L', (IMG_SIZE, IMG_SIZE), color='white')
    draw = ImageDraw.Draw(img)

    # Parse the SDF file
    tree = ET.parse(SDF_FILE)
    root = tree.getroot()
    world = root.find('world')

    # Find all <include> tags (Houses, Gas station, etc.)
    for include in world.findall('include'):
        name = include.find('name').text if include.find('name') is not None else include.find('uri').text
        pose_text = include.find('pose').text
        x, y, z, r, p, yaw = map(float, pose_text.split())
        draw_item(draw, name, x, y, yaw)

    # Find all explicit <model> tags (Trees, People, Custom Walls)
    for model in world.findall('model'):
        name = model.get('name')
        pose = model.find('pose')
        if pose is not None:
            x, y, z, r, p, yaw = map(float, pose.text.split())
            draw_item(draw, name, x, y, yaw)

    # Save the output
    img.save('scripted_map.png')
    print("Map generated successfully as 'scripted_map.png'!")

    # Write the YAML file automatically
    yaml_content = f"""image: scripted_map.png
mode: trinary
resolution: {RESOLUTION}
origin: [{-ORIGIN_OFFSET}, {-ORIGIN_OFFSET}, 0.0]
negate: 0
occupied_thresh: 0.65
free_thresh: 0.25
"""
    with open('scripted_map.yaml', 'w') as f:
        f.write(yaml_content)
    print("Map configuration saved as 'scripted_map.yaml'!")

if __name__ == '__main__':
    main()
