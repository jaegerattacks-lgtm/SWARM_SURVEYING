#!/usr/bin/env python3

# =========================================================================
# Coverage Tracker Node (Visualizes and calculates swept area)
# =========================================================================

import rclpy
from rclpy.node import Node
from nav_msgs.msg import OccupancyGrid
from tf2_ros import Buffer, TransformListener
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy, DurabilityPolicy
import numpy as np

class CoverageTracker(Node):
    def __init__(self):
        super().__init__('coverage_tracker')

        # حجم الفرشاة التي تلون الخريطة خلف الروبوت (تساوي تقريباً حجم الروبوت)
        self.brush_radius = 1.0 

        self.map_info = None
        self.coverage_grid = None
        self.static_map = None
        self.map_ready = False

        self.prev_col = None
        self.prev_row = None

        self.grid_pub = self.create_publisher(OccupancyGrid, '/coverage_grid', 10)

        map_qos = QoSProfile(
            reliability=ReliabilityPolicy.RELIABLE,
            durability=DurabilityPolicy.TRANSIENT_LOCAL,
            history=HistoryPolicy.KEEP_LAST,
            depth=1
        )
        self.map_sub = self.create_subscription(OccupancyGrid, '/map', self.map_callback, map_qos)

        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)

        # تحديث ورسم الخريطة مرتين في الثانية
        self.timer = self.create_timer(0.5, self.tracking_loop)
        
        self.get_logger().info('Coverage Tracker started! Waiting for map...')

    def map_callback(self, msg):
        if self.map_ready:
            return

        self.map_info = msg.info
        self.cols = msg.info.width
        self.rows = msg.info.height
        self.resolution = msg.info.resolution
        self.origin_x = msg.info.origin.position.x
        self.origin_y = msg.info.origin.position.y

        # مصفوفة التغطية: 0 يعني لم يزره الروبوت، 100 يعني تم مسحه
        self.coverage_grid = np.zeros((self.rows, self.cols), dtype=np.int8)
        
        # تخزين خريطة العوائق الثابتة لحساب المساحة القابلة للقيادة فقط
        self.static_map = np.array(msg.data, dtype=np.int8).reshape((self.rows, self.cols))

        self.map_ready = True
        self.get_logger().info(f'Map loaded for tracking: {self.rows}x{self.cols} cells.')

    def tracking_loop(self):
        if not self.map_ready:
            return

        try:
            trans = self.tf_buffer.lookup_transform('map', 'base_link', rclpy.time.Time())
            rx = trans.transform.translation.x
            ry = trans.transform.translation.y
        except Exception:
            return

        col = int((rx - self.origin_x) / self.resolution)
        row = int((ry - self.origin_y) / self.resolution)

        if not (0 <= row < self.rows and 0 <= col < self.cols):
            return

        self.mark_brush_area(row, col)

        if self.prev_row is not None:
            self.interpolate_cells(self.prev_row, self.prev_col, row, col)

        self.prev_row = row
        self.prev_col = col

        self.log_coverage()
        self.publish_grid()

    def mark_brush_area(self, center_row, center_col):
        # تلوين الخلايا المحيطة بالروبوت بناءً على حجم الفرشاة
        brush_cells = int(self.brush_radius / self.resolution)
        
        for r in range(center_row - brush_cells, center_row + brush_cells + 1):
            for c in range(center_col - brush_cells, center_col + brush_cells + 1):
                if 0 <= r < self.rows and 0 <= c < self.cols:
                    # تلوين المساحة الفارغة فقط (تجاهل الجدران)
                    if self.static_map[r, c] == 0:
                        self.coverage_grid[r, c] = 100

    def interpolate_cells(self, r0, c0, r1, c1):
        dr = abs(r1 - r0)
        dc = abs(c1 - c0)
        sr = 1 if r0 < r1 else -1
        sc = 1 if c0 < c1 else -1
        err = dr - dc

        while True:
            self.mark_brush_area(r0, c0)
            if r0 == r1 and c0 == c1:
                break
            e2 = 2 * err
            if e2 > -dc:
                err -= dc
                r0 += sr
            if e2 < dr:
                err += dr
                c0 += sc

    def log_coverage(self):
        # حساب المساحة القابلة للقيادة (البيضاء)
        drivable_cells = np.sum(self.static_map == 0)
        visited_cells = np.sum(self.coverage_grid == 100)

        if drivable_cells > 0:
            real_percent = (visited_cells / drivable_cells) * 100
            self.get_logger().info(f'Live Coverage: {real_percent:.1f}% ({visited_cells}/{drivable_cells} cells)')

    def publish_grid(self):
        msg = OccupancyGrid()
        msg.header.frame_id = 'map'
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.info = self.map_info

        # دمج العوائق الأصلية مع ما تم مسحه ليظهر بشكل ملون في RViz
        display_grid = self.coverage_grid.copy()
        display_grid[self.static_map != 0] = 100 # جعل الحوائط سوداء للتمييز

        msg.data = display_grid.flatten().tolist()
        self.grid_pub.publish(msg)

def main(args=None):
    rclpy.init(args=args)
    node = CoverageTracker()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()

if __name__ == '__main__':
    main()
