#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from nav_msgs.msg import OccupancyGrid
from geometry_msgs.msg import PoseStamped
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy, DurabilityPolicy
from tf2_ros import Buffer, TransformListener
import numpy as np
import math

# --- التضمينات الجديدة الخاصة بـ Action Client ---
from rclpy.action import ActionClient
from nav2_msgs.action import NavigateToPose

class StigmergyPlanner(Node):
    def __init__(self):
        super().__init__('stigmergy_planner')
        
        self.map_received = False
        self.pose_received = False 
        self.grid = None  
        self.static_map = None 
        self.curr_x, self.curr_y = 0.0, 0.0
        self.curr_yaw = 0.0
        self.target_coverage = 90.0
        self.total_traversable_cells = 0
        
        # State tracking
        self.active_goal_x = None
        self.active_goal_y = None
        self.active_goal_yaw = None 
        
        # Anti-Stuck Tracking
        self.last_x = 0.0
        self.last_y = 0.0
        self.stuck_ticks = 0
        
        # Restored Dynamic Boundaries
        self.min_x, self.max_x = 0.0, 0.0
        self.min_y, self.max_y = 0.0, 0.0
        
        map_qos = QoSProfile(
            reliability=ReliabilityPolicy.RELIABLE,
            durability=DurabilityPolicy.TRANSIENT_LOCAL,
            history=HistoryPolicy.KEEP_LAST,
            depth=1
        )
        
        self.map_sub = self.create_subscription(OccupancyGrid, '/map', self.map_callback, map_qos)
        
        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)
        
        self.pheromone_pub = self.create_publisher(OccupancyGrid, '/pheromone_map', 10)

        # --- استبدال Publisher بـ Action Client ---
        self.nav_to_pose_client = ActionClient(self, NavigateToPose, 'navigate_to_pose')

        # Split timers for max performance: Paint fast, plan slow
        self.paint_timer = self.create_timer(0.2, self.update_pose_and_paint)
        self.plan_timer = self.create_timer(1.5, self.planning_loop)
        
        self.get_logger().info("Stigmergy Planner: Dynamic Boundaries + Proximity Safety Check Active (ActionClient Mode).")

    def euler_from_quaternion(self, q):
        siny_cosp = 2 * (q.w * q.z + q.x * q.y)
        cosy_cosp = 1 - 2 * (q.y * q.y + q.z * q.z)
        return math.atan2(siny_cosp, cosy_cosp)

    def map_callback(self, msg):
        if not self.map_received:
            self.info = msg.info
            self.static_map = np.array(msg.data, dtype=np.int8)
            self.grid = np.copy(self.static_map) 
            self.total_traversable_cells = np.count_nonzero(self.static_map == 0)
            
            # --- DYNAMIC BOUNDARY CALCULATION FOR ANY MAP ---
            safety_margin = 0.35 
            res = msg.info.resolution
            self.min_x = msg.info.origin.position.x + safety_margin
            self.max_x = msg.info.origin.position.x + (msg.info.width * res) - safety_margin
            self.min_y = msg.info.origin.position.y + safety_margin
            self.max_y = msg.info.origin.position.y + (msg.info.height * res) - safety_margin

            self.map_received = True
            self.get_logger().info(f"Map Loaded Dynamically. Bounds: X({self.min_x:.1f}, {self.max_x:.1f}), Y({self.min_y:.1f}, {self.max_y:.1f})")

    def is_cell_safe(self, gx, gy, safe_dist_m=0.35):
        """Scans a circular radius around a target to ensure it is not touching a wall."""
        safe_cells = int(safe_dist_m / self.info.resolution)
        for i in range(-safe_cells, safe_cells + 1):
            for j in range(-safe_cells, safe_cells + 1):
                # Circular radius check
                if i*i + j*j > safe_cells*safe_cells:
                    continue
                
                check_gx = gx + i
                check_gy = gy + j
                
                if 0 <= check_gx < self.info.width and 0 <= check_gy < self.info.height:
                    idx = check_gy * self.info.width + check_gx
                    # Reject target if it touches a lethal obstacle (100) or unknown space (-1)
                    if self.static_map[idx] == 100 or self.static_map[idx] == -1:
                        return False
        return True

    def update_pose_and_paint(self):
        if not self.map_received: return
        
        try:
            trans = self.tf_buffer.lookup_transform('map', 'base_link', rclpy.time.Time())
            self.curr_x = trans.transform.translation.x
            self.curr_y = trans.transform.translation.y
            self.curr_yaw = self.euler_from_quaternion(trans.transform.rotation)
            self.pose_received = True
        except Exception as e:
            return 
            
        gx = int((self.curr_x - self.info.origin.position.x) / self.info.resolution)
        gy = int((self.curr_y - self.info.origin.position.y) / self.info.resolution)
        
        brush_radius_m = 0.5 
        radius = int(brush_radius_m / self.info.resolution)
        
        for i in range(-radius, radius):
            for j in range(-radius, radius):
                if 0 <= (gy+j) < self.info.height and 0 <= (gx+i) < self.info.width:
                    idx = (gy + j) * self.info.width + (gx + i)
                    if self.grid[idx] == 0:
                        self.grid[idx] = 60
                        
        viz_msg = OccupancyGrid()
        viz_msg.header.stamp.sec = 0
        viz_msg.header.frame_id = 'map'
        viz_msg.info = self.info
        viz_msg.data = self.grid.tolist()
        self.pheromone_pub.publish(viz_msg)

    def planning_loop(self):
        if not self.map_received or not self.pose_received: return

        current_cov = (np.count_nonzero(self.grid == 60) / self.total_traversable_cells) * 100
        self.get_logger().info(f"Current Coverage: {current_cov:.2f}%")

        if current_cov >= self.target_coverage:
            self.get_logger().info("Target Coverage Reached!")
            return

        if self.active_goal_x is not None:
            dist_to_goal = math.hypot(self.curr_x - self.active_goal_x, self.curr_y - self.active_goal_y)
            dist_moved = math.hypot(self.curr_x - self.last_x, self.curr_y - self.last_y)
            self.last_x = self.curr_x
            self.last_y = self.curr_y
            
            if dist_to_goal > 0.9:
                if dist_moved < 0.05: 
                    self.stuck_ticks += 1
                else:
                    self.stuck_ticks = 0 
                    
                if self.stuck_ticks > 5:
                    self.get_logger().warn("Nav2 missed the goal or got stuck! Resending...")
                    self.send_nav2_goal(self.active_goal_x, self.active_goal_y, self.active_goal_yaw)
                    self.stuck_ticks = 0
                
                return 

        best_goal = None
        search_radius = [1.2, 2.0, 3.5] 
        
        # 1. Forward Search
        for dist in search_radius:
            tx_forward = self.curr_x + dist * math.cos(self.curr_yaw)
            ty_forward = self.curr_y + dist * math.sin(self.curr_yaw)
            if self.min_x < tx_forward < self.max_x and self.min_y < ty_forward < self.max_y:
                gx_f = int((tx_forward - self.info.origin.position.x) / self.info.resolution)
                gy_f = int((ty_forward - self.info.origin.position.y) / self.info.resolution)
                if 0 <= gx_f < self.info.width and 0 <= gy_f < self.info.height:
                    if self.grid[gy_f * self.info.width + gx_f] == 0 and self.is_cell_safe(gx_f, gy_f):
                        best_goal = (tx_forward, ty_forward, self.curr_yaw)
                        break 

        # 2. Angular Search
        if not best_goal:
            relative_angles = [0, 30, -30, 60, -60, 90, -90, 120, -120, 180]
            for dist in search_radius:
                for angle_offset in relative_angles: 
                    check_angle = self.curr_yaw + math.radians(angle_offset)
                    tx = self.curr_x + dist * math.cos(check_angle)
                    ty = self.curr_y + dist * math.sin(check_angle)
                    if self.min_x < tx < self.max_x and self.min_y < ty < self.max_y:
                        gx = int((tx - self.info.origin.position.x) / self.info.resolution)
                        gy = int((ty - self.info.origin.position.y) / self.info.resolution)
                        if self.grid[gy * self.info.width + gx] == 0 and self.is_cell_safe(gx, gy):
                            best_goal = (tx, ty, check_angle)
                            break
                if best_goal: break
                
        # 3. Global Nearest Escape Hatch
        if not best_goal:
            self.get_logger().info("Stuck! Searching globally for the nearest safe unvisited cell...")
            unvisited_indices = np.where(self.grid == 0)[0]
            if len(unvisited_indices) > 0:
                gy_unvisited, gx_unvisited = np.unravel_index(unvisited_indices, (self.info.height, self.info.width))
                tx_unvisited = (gx_unvisited * self.info.resolution) + self.info.origin.position.x
                ty_unvisited = (gy_unvisited * self.info.resolution) + self.info.origin.position.y
                
                valid_mask = (tx_unvisited >= self.min_x) & (tx_unvisited <= self.max_x) & \
                             (ty_unvisited >= self.min_y) & (ty_unvisited <= self.max_y)
                
                tx_valid = tx_unvisited[valid_mask]
                ty_valid = ty_unvisited[valid_mask]
                
                if len(tx_valid) > 0:
                    distances_sq = (tx_valid - self.curr_x)**2 + (ty_valid - self.curr_y)**2
                    sorted_indices = np.argsort(distances_sq)
                    
                    for idx in sorted_indices:
                        nearest_tx = tx_valid[idx]
                        nearest_ty = ty_valid[idx]
                        gx = int((nearest_tx - self.info.origin.position.x) / self.info.resolution)
                        gy = int((nearest_ty - self.info.origin.position.y) / self.info.resolution)
                        
                        if self.is_cell_safe(gx, gy):
                            angle_to_target = math.atan2(nearest_ty - self.curr_y, nearest_tx - self.curr_x)
                            best_goal = (nearest_tx, nearest_ty, angle_to_target)
                            self.get_logger().info(f"Escape Hatch Activated! Targeting safe cell: x={nearest_tx:.2f}, y={nearest_ty:.2f}")
                            break
        
        if best_goal:
            final_tx = best_goal[0] - 0.2 * math.cos(best_goal[2])
            final_ty = best_goal[1] - 0.2 * math.sin(best_goal[2])
            
            self.active_goal_x = final_tx
            self.active_goal_y = final_ty
            self.active_goal_yaw = best_goal[2]
            
            self.stuck_ticks = 0
            self.last_x = self.curr_x
            self.last_y = self.curr_y
            
            self.send_nav2_goal(final_tx, final_ty, best_goal[2])

    # --- دوال Action Client الجديدة للتعامل مع Nav2 ---
    def send_nav2_goal(self, x, y, yaw):
        if not self.nav_to_pose_client.wait_for_server(timeout_sec=1.0):
            self.get_logger().warn("Nav2 Action Server not available! Retrying next loop...")
            self.active_goal_x = None  # تفريغ الهدف للمحاولة مرة أخرى
            return

        goal_msg = NavigateToPose.Goal()
        goal_msg.pose.header.frame_id = "map"
        goal_msg.pose.header.stamp = self.get_clock().now().to_msg()
        goal_msg.pose.pose.position.x = float(x)
        goal_msg.pose.pose.position.y = float(y)
        goal_msg.pose.pose.orientation.z = math.sin(yaw / 2.0)
        goal_msg.pose.pose.orientation.w = math.cos(yaw / 2.0)
        
        self.get_logger().info(f"Targeting Action: x={x:.2f}, y={y:.2f}")
        
        # إرسال الهدف وربط الردود بالدوال المخصصة
        send_goal_future = self.nav_to_pose_client.send_goal_async(goal_msg)
        send_goal_future.add_done_callback(self.goal_response_callback)

    def goal_response_callback(self, future):
        goal_handle = future.result()
        if not goal_handle.accepted:
            self.get_logger().warn("Nav2 REJECTED the goal! Forcing replan...")
            # مسح الهدف الحالي ليتم حساب هدف جديد فوراً في اللفة القادمة
            self.active_goal_x = None
            self.active_goal_y = None
            return

        self.get_logger().info("Nav2 ACCEPTED the goal. Moving...")
        get_result_future = goal_handle.get_result_async()
        get_result_future.add_done_callback(self.get_result_callback)

    def get_result_callback(self, future):
        status = future.result().status
        if status == 4:  # 4 يعني SUCCEEDED
            self.get_logger().info("Goal Reached Successfully!")
            self.active_goal_x = None
            self.active_goal_y = None
        else:
            self.get_logger().warn(f"Goal failed or canceled mid-way (Status: {status}). Replanning...")
            self.active_goal_x = None
            self.active_goal_y = None

def main(args=None):
    rclpy.init(args=args)
    node = StigmergyPlanner()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok(): rclpy.shutdown()

if __name__ == '__main__':
    main()

