#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry
from tf2_ros import TransformBroadcaster
from geometry_msgs.msg import TransformStamped

class PerfectTfBroadcaster(Node):
    def __init__(self):
        super().__init__('perfect_tf_broadcaster')
        
        # الاشتراك في الأودومتري المثالي القادم من جازيبو
        self.subscription = self.create_subscription(
            Odometry,
            '/perfect_odom',
            self.odom_callback,
            10)
            
        # إنشاء أداة بث الـ TF
        self.tf_broadcaster = TransformBroadcaster(self)
        self.get_logger().info("Perfect TF Broadcaster Started: Bridging /perfect_odom to TF tree.")

    def odom_callback(self, msg):
        t = TransformStamped()
        
        # نسخ البيانات من رسالة الأودومتري إلى رسالة الـ TF
        t.header.stamp = msg.header.stamp
        t.header.frame_id = 'odom'
        t.child_frame_id = 'base_link'
        
        t.transform.translation.x = msg.pose.pose.position.x
        t.transform.translation.y = msg.pose.pose.position.y
        t.transform.translation.z = msg.pose.pose.position.z
        t.transform.rotation = msg.pose.pose.orientation
        
        # بث التحويل
        self.tf_broadcaster.sendTransform(t)

def main(args=None):
    rclpy.init(args=args)
    node = PerfectTfBroadcaster()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
