#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient
from nav_msgs.msg import OccupancyGrid
from visualization_msgs.msg import Marker, MarkerArray
from nav2_msgs.action import NavigateToPose
from action_msgs.msg import GoalStatus
from tf2_ros import Buffer, TransformListener
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy, DurabilityPolicy
import numpy as np

class SweepSupervisorNode(Node):
    def __init__(self):
        super().__init__('sweep_supervisor_node')
        
        # --- [إعدادات التغطية الأساسية] ---
        self.strip_width = 2.0  
        self.point_step = 2.0   
        
        # تم إزالة مسافة التجاوز، الروبوت سيقف عند كل نقطة بالكامل.
        
        self.map_received = False             
        self.pose_received = False            
        self.mission_started = False          
        self.generation_done = False
        
        self.warmup_ticks = 0                 
        self.required_warmup_ticks = 70       
        
        self.static_map = None
        self.map_info = None
        
        self.waypoints = []                   
        self.current_waypoint_idx = 0         
        self.is_navigating = False      

        map_qos = QoSProfile(
            reliability=ReliabilityPolicy.RELIABLE,
            durability=DurabilityPolicy.TRANSIENT_LOCAL,
            history=HistoryPolicy.KEEP_LAST,
            depth=1
        )
        self.map_sub = self.create_subscription(OccupancyGrid, '/map', self.map_callback, map_qos)
        
        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)
        
        self.nav_client = ActionClient(self, NavigateToPose, 'navigate_to_pose')
        self.marker_pub = self.create_publisher(MarkerArray, '/tsp_waypoints_viz', 10)
        self.marker_array = MarkerArray()
        
        self.loop_timer = self.create_timer(0.1, self.supervisor_loop)
        self.get_logger().info("Stop-and-Go Supervisor initialized. Waiting for map...")

    def map_callback(self, msg):
        if self.map_received: return
        self.map_info = msg.info 
        self.static_map = np.array(msg.data, dtype=np.int8) 
        self.map_received = True
        self.get_logger().info("Static map received.")

    def generate_lawnmower_path(self):
        self.get_logger().info("Generating waypoints...")
        resolution = self.map_info.resolution
        width = self.map_info.width
        height = self.map_info.height
        
        safe_margin_cells = int(0.35 / resolution)
        
        min_x = self.map_info.origin.position.x
        max_x = min_x + (width * resolution)
        min_y = self.map_info.origin.position.y
        max_y = min_y + (height * resolution)
        
        self.waypoints = [] 
        y_curr = min_y + (self.strip_width / 2.0)
        left_to_right = True  
        
        while y_curr < max_y:
            x_points = np.arange(min_x + (self.point_step / 2.0), max_x, self.point_step)
            if not left_to_right: x_points = x_points[::-1]
                
            for x_curr in x_points:
                mx = int((x_curr - min_x) / resolution)
                my = int((y_curr - min_y) / resolution)
                
                if 0 <= mx < width and 0 <= my < height:
                    if self.static_map[my * width + mx] == 0:
                        is_safe = True
                        for dy in range(-safe_margin_cells, safe_margin_cells + 1):
                            for dx in range(-safe_margin_cells, safe_margin_cells + 1):
                                check_x = mx + dx; check_y = my + dy
                                if 0 <= check_x < width and 0 <= check_y < height:
                                    if self.static_map[check_y * width + check_x] != 0:
                                        is_safe = False; break
                            if not is_safe: break
                        if is_safe:
                            self.waypoints.append((float(x_curr), float(y_curr)))
            
            y_curr += self.strip_width
            left_to_right = not left_to_right
            
        for idx, wp in enumerate(self.waypoints):
            pm = Marker()
            pm.header.frame_id = "map"; pm.ns = "pts"; pm.id = idx; pm.type = Marker.SPHERE
            pm.pose.position.x = wp[0]; pm.pose.position.y = wp[1]; pm.pose.position.z = 0.1
            pm.scale.x = 0.15; pm.scale.y = 0.15; pm.scale.z = 0.15
            pm.color.r = 1.0; pm.color.g = 0.5; pm.color.b = 0.0; pm.color.a = 1.0
            
            tm = Marker()
            tm.header.frame_id = "map"; tm.ns = "txt"; tm.id = idx + 1000; tm.type = Marker.TEXT_VIEW_FACING
            tm.pose.position.x = wp[0]; tm.pose.position.y = wp[1]; tm.pose.position.z = 0.3 
            tm.scale.z = 0.15 
            tm.color.r = 1.0; tm.color.g = 1.0; tm.color.b = 1.0; tm.color.a = 1.0
            tm.text = str(idx)
            
            self.marker_array.markers.extend([pm, tm])

        self.get_logger().info(f"Generated {len(self.waypoints)} goals. Starting execution.")
        self.generation_done = True

    def supervisor_loop(self):
        if not self.map_received: return
        if self.generation_done: self.marker_pub.publish(self.marker_array)

        if self.warmup_ticks < self.required_warmup_ticks:
            self.warmup_ticks += 1
            if self.warmup_ticks % 10 == 0:
                self.get_logger().info(f"Warming up Nav2... {self.warmup_ticks/10:.0f}/{self.required_warmup_ticks/10:.0f}s")
            return
            
        if not self.mission_started:
            self.generate_lawnmower_path()
            self.mission_started = True
            self.send_next_waypoint() 
            return
            
        if self.current_waypoint_idx >= len(self.waypoints):
            if not self.is_navigating:
                self.get_logger().info("Mission Complete!")
                self.loop_timer.cancel() 
            return

        # تم إزالة حساب المسافة من هنا. الحلقة الآن فقط تنتظر انتهاء الملاحة.
        if self.is_navigating:
            return

    def send_next_waypoint(self):
        if self.current_waypoint_idx >= len(self.waypoints): return
        
        target_wp = self.waypoints[self.current_waypoint_idx]
        
        goal_msg = NavigateToPose.Goal()
        goal_msg.pose.header.frame_id = "map"
        goal_msg.pose.header.stamp = self.get_clock().now().to_msg()
        goal_msg.pose.pose.position.x = float(target_wp[0])
        goal_msg.pose.pose.position.y = float(target_wp[1])
        goal_msg.pose.pose.orientation.w = 1.0
        
        self.get_logger().info(f"Nav2 Dispatch -> WP [{self.current_waypoint_idx}] at (X={target_wp[0]:.2f}, Y={target_wp[1]:.2f})")
        
        self.nav_client.wait_for_server() 
        self.send_goal_future = self.nav_client.send_goal_async(goal_msg)
        self.send_goal_future.add_done_callback(self.goal_response_callback)
        self.is_navigating = True # نقفل الإرسال لحد ما الهدف يخلص

    def goal_response_callback(self, future):
        goal_handle = future.result()
        if not goal_handle.accepted:
            self.get_logger().error("Nav2 rejected the goal! Skipping to next...")
            self.is_navigating = False
            self.current_waypoint_idx += 1 
            self.send_next_waypoint()
            return
       
        self.get_result_future = goal_handle.get_result_async()
        self.get_result_future.add_done_callback(self.get_result_callback)

    def get_result_callback(self, future):
        status = future.result().status
        self.is_navigating = False # نفتح باب الإرسال للهدف الجديد
        
        if status == GoalStatus.STATUS_SUCCEEDED:
            self.get_logger().info(f"Successfully reached WP [{self.current_waypoint_idx}]")
            self.current_waypoint_idx += 1 
            self.send_next_waypoint()
        elif status == GoalStatus.STATUS_ABORTED:
            self.get_logger().error("Nav2 Aborted! Obstacle blocked path. Skipping WP.")
            self.current_waypoint_idx += 1 
            self.send_next_waypoint()
        else:
            self.get_logger().warn(f"Goal ended with status: {status}. Moving to next.")
            self.current_waypoint_idx += 1 
            self.send_next_waypoint()

def main(args=None):
    rclpy.init(args=args)
    node = SweepSupervisorNode()
    try: rclpy.spin(node) 
    except KeyboardInterrupt: pass
    finally:
        node.destroy_node()
        if rclpy.ok(): rclpy.shutdown()

if __name__ == '__main__':
    main()
