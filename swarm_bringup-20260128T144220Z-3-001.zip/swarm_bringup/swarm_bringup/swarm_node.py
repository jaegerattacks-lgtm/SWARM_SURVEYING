#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import cv2
import numpy as np
import math
import time

# ==============================================================================
# 1. PID CONTROLLER CLASS
# ==============================================================================
class PIDController:
    # FIXED: _init_ -> __init__ (Double underscore)
    def __init__(self, kp, ki, kd):
        self.kp = kp  
        self.ki = ki  
        self.kd = kd  
        self.prev_error = 0.0
        self.integral = 0.0
    
    def update(self, error, dt):
        p_term = self.kp * error
        self.integral += error * dt
        self.integral = max(min(self.integral, 1.0), -1.0)
        i_term = self.ki * self.integral
        derivative = (error - self.prev_error) / dt
        d_term = self.kd * derivative
        self.prev_error = error
        return p_term + i_term + d_term

    def reset(self):
        self.prev_error = 0.0
        self.integral = 0.0

# ==============================================================================
# 2. MATH HELPER
# ==============================================================================
def euler_from_quaternion(quaternion):
    x, y, z, w = quaternion.x, quaternion.y, quaternion.z, quaternion.w
    siny_cosp = 2 * (w * z + x * y)
    cosy_cosp = 1 - 2 * (y * y + z * z)
    return math.atan2(siny_cosp, cosy_cosp)

# ==============================================================================
# 3. MAIN NODE CLASS
# ==============================================================================
class SmartSwarmNavigator(Node):
    # FIXED: _init_ -> __init__ (Double underscore)
    def __init__(self):
        super().__init__("smart_swarm_navigator")
        self.bridge = CvBridge()

        # --- A. IDENTITY SETUP ---
        self.declare_parameter("robot_name", "robot1")
        self.robot_name = self.get_parameter("robot_name").value
        
        # --- B. GOAL ASSIGNMENT ---
        self.GOAL_X = 25.0
        if "robot1" in self.robot_name:   self.GOAL_Y = 0.0
        elif "robot2" in self.robot_name: self.GOAL_Y = 3.0
        elif "robot3" in self.robot_name: self.GOAL_Y = -3.0
        else:                             self.GOAL_Y = 0.0

        # --- C. CONSTANTS ---
        self.CAM_HEIGHT = 0.078
        self.CAM_CENTER_Y = 120.0
        self.RAD_PER_PIXEL = 0.00355
        self.SWARM_SAFE_DISTANCE = 0.8 
        
        # --- D. INITIALIZATION ---
        self.pid = PIDController(kp=0.8, ki=0.005, kd=0.15)
        self.x = 0.0
        self.y = 0.0
        self.yaw = 0.0
        self.state = "CRUISE" 
        self.turn_direction = 1.0 
        self.stuck_timer = 0
        self.closest_dist = 99.9

        # --- E. SWARM COMMUNICATION ---
        self.neighbors = {} 
        self.setup_swarm_comms()

        # --- F. ROS PUBLISHERS/SUBSCRIBERS ---
        self.cmd_pub = self.create_publisher(Twist, f"/{self.robot_name}/diff_drive_controller/cmd_vel_unstamped", 10)
        self.create_subscription(Odometry, f"/{self.robot_name}/diff_drive_controller/odom", self.odom_callback, 10)
        self.debug_pub = self.create_publisher(Image, f"/{self.robot_name}/camera_sensor/debug_view", 10)
        
        target_sensor_name = f"{self.robot_name}_camera_sensor"
        found_topic = self.find_camera_topic(target_sensor_name)
        self.get_logger().info(f"--- {self.robot_name} FOUND CAMERA: {found_topic} ---")
        self.create_subscription(Image, found_topic, self.vision_callback, 10)
        
        self.create_timer(0.1, self.control_loop)
        self.get_logger().info(f"--- {self.robot_name} SWARM READY (Target: {self.GOAL_Y}) ---")

    # ==========================================================================
    # 4. SWARM SETUP FUNCTIONS
    # ==========================================================================
    def setup_swarm_comms(self):
        all_robots = ["robot1", "robot2", "robot3"]
        for r in all_robots:
            if r != self.robot_name:
                self.create_subscription(
                    Odometry, 
                    f"/{r}/diff_drive_controller/odom", 
                    lambda msg, name=r: self.neighbor_callback(msg, name), 
                    10
                )

    def neighbor_callback(self, msg, neighbor_name):
        nx = msg.pose.pose.position.x
        ny = msg.pose.pose.position.y
        self.neighbors[neighbor_name] = (nx, ny)

    def find_camera_topic(self, sensor_name):
        for i in range(10): 
            topic_list = self.get_topic_names_and_types()
            for name, types in topic_list:
                if sensor_name in name and "image_raw" in name:
                    return name
            time.sleep(0.5)
        return f"/{self.robot_name}/{self.robot_name}_camera_sensor/image_raw"

    # ==========================================================================
    # 6. SENSOR CALLBACKS
    # ==========================================================================
    def odom_callback(self, msg):
        self.x = msg.pose.pose.position.x
        self.y = msg.pose.pose.position.y
        self.yaw = euler_from_quaternion(msg.pose.pose.orientation)

    def vision_callback(self, msg):
        try:
            cv_image = self.bridge.imgmsg_to_cv2(msg, "bgr8")
            gray = cv2.cvtColor(cv_image, cv2.COLOR_BGR2GRAY)
            edges = cv2.Canny(gray, 50, 150)
            height, width = edges.shape

            midpoint = width // 2
            left_view = edges[:, :midpoint]
            right_view = edges[:, midpoint:]

            danger_left = np.max(np.argwhere(left_view > 0)[:, 0]) if np.any(left_view > 0) else 0
            danger_right = np.max(np.argwhere(right_view > 0)[:, 0]) if np.any(right_view > 0) else 0
            
            if danger_left > danger_right:
                self.turn_direction = -1.0 
            else:
                self.turn_direction = 1.0 

            global_max_y = max(danger_left, danger_right)
            if global_max_y > self.CAM_CENTER_Y:
                angle = (global_max_y - self.CAM_CENTER_Y) * self.RAD_PER_PIXEL
                self.closest_dist = self.CAM_HEIGHT / math.tan(angle)
            else:
                self.closest_dist = 99.9 

            debug_img = cv_image.copy()
            cv2.putText(debug_img, f"State: {self.state}", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
            self.debug_pub.publish(self.bridge.cv2_to_imgmsg(debug_img, "bgr8"))

        except Exception as e:
            self.get_logger().error(f"Vision error: {e}")

    # ==========================================================================
    # 7. SWARM LOGIC
    # ==========================================================================
    def get_swarm_repulsion(self):
        repulsion_yaw = 0.0
        active_forces = 0

        for name, (nx, ny) in self.neighbors.items():
            # FIXED: Math error *2 -> **2 (Squared)
            dist = math.sqrt((self.x - nx)**2 + (self.y - ny)**2)
            
            if dist < self.SWARM_SAFE_DISTANCE:
                angle_to_neighbor = math.atan2(ny - self.y, nx - self.x)
                angle_away = angle_to_neighbor + math.pi 
                repulsion_yaw += angle_away
                active_forces += 1
                self.get_logger().warn(f"Too close to {name}! ({dist:.2f}m) Pushing away.")

        if active_forces > 0:
            return repulsion_yaw / active_forces, True
        return 0.0, False

    # ==========================================================================
    # 8. MAIN CONTROL LOOP
    # ==========================================================================
    def control_loop(self):
        cmd = Twist()
        
        # Priority 1: Avoid Crash
        if self.closest_dist < 0.2:
            self.state = "STUCK_REVERSE"
            self.stuck_timer = 15
            self.pid.reset()
        
        if self.state == "STUCK_REVERSE":
            if self.stuck_timer > 0:
                cmd.linear.x = -0.2
                cmd.angular.z = 0.0
                self.stuck_timer -= 1
            else:
                self.state = "CRUISE"
            self.cmd_pub.publish(cmd)
            return

        # Priority 2: Swarm Separation
        repulsion_angle, is_too_close = self.get_swarm_repulsion()

        # Priority 3: Avoid Obstacle
        if self.closest_dist < 0.4:
            self.state = "AVOID_OBSTACLE"
            cmd.linear.x = 0.15 
            cmd.angular.z = 0.8 * self.turn_direction 
            self.pid.reset()
            
        elif is_too_close:
            self.state = "SWARM_SEPARATION"
            yaw_error = repulsion_angle - self.yaw
            while yaw_error > math.pi: yaw_error -= 2 * math.pi
            while yaw_error < -math.pi: yaw_error += 2 * math.pi
            
            cmd.angular.z = 0.6 * yaw_error 
            cmd.linear.x = 0.5
            self.pid.reset()

        # Priority 4: Mission
        else:
            self.state = "CRUISE"
            dx = self.GOAL_X - self.x
            dy = self.GOAL_Y - self.y
            # FIXED: Math error *2 -> **2 (Squared)
            dist_to_goal = math.sqrt(dx**2 + dy**2)
            
            if dist_to_goal < 0.5:
                cmd.linear.x = 0.0
                cmd.angular.z = 0.0
            else:
                target_yaw = math.atan2(dy, dx)
                yaw_error = target_yaw - self.yaw
                while yaw_error > math.pi: yaw_error -= 2 * math.pi
                while yaw_error < -math.pi: yaw_error += 2 * math.pi
                
                steering = self.pid.update(yaw_error, dt=0.1)
                cmd.linear.x = 0.35
                cmd.angular.z = steering

        self.cmd_pub.publish(cmd)

def main(args=None):
    rclpy.init(args=args)
    node = SmartSwarmNavigator()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

# FIXED: _name_ -> __name__
if __name__ == "__main__":
    main()