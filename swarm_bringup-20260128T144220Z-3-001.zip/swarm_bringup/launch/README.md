(test one)
one_robot_control.launch.py:
this file spawn one robot using its urdf (robot discription+controller+camera) in an empty world
you should make sure that you change the pathes befor launch this file or it will not work


(test two)
spawn_robot.launch.py:
this file spawn one robot using its xacro file(robot discription+controller+camera) in a custom world  called (random_obstical)
you should make sure that you change the pathe befor launch this file or it will not work

(test three)
bring_up_3_robots.launch.py:
this file spawn the three robots using the final xacro file (swarm_robot) in a custom world
you should make sure that you change the pathe befor launch this file or it will not work

(test four)
all_in_one.launch.py:
this file launch the three robots in the custom world and apply the swarm algorithm


please don not try to make a big changes in the launch files to keep the right sequance of the spawn process

for evry lunch file you should check that the topics of the controller and the camera are working correctly 
if you do not how ask gemini
 
