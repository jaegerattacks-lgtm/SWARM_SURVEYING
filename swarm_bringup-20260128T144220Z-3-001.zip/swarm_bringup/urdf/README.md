 robot_fixed.urdf :
the robot discription+camera plugin+controller plugin
this file will not work on your own computer because it contain a spesific pathes that is only appear in my computer  you should change them into your path



 robot_fixed.urdf.xacro :
 the robot discription+camera plugin+controller plugin put in xacro format 


swarm_robot.urdf.xacro:
it is the final robot discreption with required namespace and prifex and tha is wha we will use for swarm 

important note :
to make it works on your computer you shoulg change this path
<xacro:property name="mesh_path" value="file:///home/nour/my_friend_ws/install/swarm_bringup/share/swarm_bringup/meshes"/>
to your own 

to do that change this section from  nour/my_friend_ws to (your user name)/(your work space name)
{you can applay this steps on robot_fixed.urdf.xacro also}
