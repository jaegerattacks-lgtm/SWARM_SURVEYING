from setuptools import setup
import os
from glob import glob

package_name = 'swarm_bringup'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    data_files=[
        # Register the package in the ament index
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),

        # 1. Install launch files
        (os.path.join('share', package_name, 'launch'), glob('launch/*.launch.py')),
        
        # 2. Install world files
        (os.path.join('share', package_name, 'worlds'), glob('worlds/*.world')),

        # 3. Install URDF, Xacro, and Gazebo snippets
        (os.path.join('share', package_name, 'urdf'), 
         glob('urdf/*.urdf') + glob('urdf/*.xacro') + glob('urdf/*.gazebo')),

        # 4. Install Meshes
        (os.path.join('share', package_name, 'meshes'), 
         glob('meshes/*.STL') + glob('meshes/*.stl') + glob('meshes/*.dae')),

        # 5. Install Config files
        (os.path.join('share', package_name, 'config'), glob('config/*.yaml')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='srh17',
    maintainer_email='srh17@todo.todo',
    description='swarm bringup',
    license='Apache License 2.0',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            # CRITICAL UPDATE HERE:
            'swarm_node = swarm_bringup.swarm_node:main',
        ],
    },
)
